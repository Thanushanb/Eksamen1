namespace Core.Filter;

public class UserFilter
{
    public string? LocationName { get; set; }
    public string? Education { get; set; }
    public string? Name { get; set; }
    public string? Internshipyear { get; set; }
    
    public bool? IsActive { get; set; }
}
